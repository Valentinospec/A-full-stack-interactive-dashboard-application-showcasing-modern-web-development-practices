import { Request, Response } from 'express';

const dashboardController = {
  getStats: async (req: Request, res: Response) => {
    try {
      const stats = {
        totalUsers: 1234,
        activeUsers: 567,
        revenue: 45000,
        growth: 12.5,
      };
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch stats' });
    }
  },

  getChartData: async (req: Request, res: Response) => {
    try {
      const chartData = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
          {
            label: 'Revenue',
            data: [30000, 35000, 32000, 40000, 45000, 50000],
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
          },
          {
            label: 'Users',
            data: [800, 900, 850, 1000, 1100, 1234],
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
          },
        ],
      };
      res.json(chartData);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch chart data' });
    }
  },
};

export default dashboardController;